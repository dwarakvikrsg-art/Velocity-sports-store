
import { Category, Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Elite Pro Run X",
    category: Category.SHOES,
    price: 129.99,
    image: "https://picsum.photos/seed/shoes1/600/600",
    description: "Next-gen cushioning for the serious athlete.",
    isFeatured: true
  },
  {
    id: 2,
    name: "Willow Master Grade 1",
    category: Category.BATS,
    price: 299.99,
    image: "https://picsum.photos/seed/bat1/600/600",
    description: "Hand-crafted English willow for maximum power.",
    isFeatured: true
  },
  {
    id: 3,
    name: "Official Match Ball",
    category: Category.BALLS,
    price: 45.00,
    image: "https://picsum.photos/seed/ball1/600/600",
    description: "FIFA quality pro certified match ball.",
    isFeatured: false
  },
  {
    id: 4,
    name: "Victory Team Jersey",
    category: Category.JERSEYS,
    price: 75.00,
    image: "https://picsum.photos/seed/jersey1/600/600",
    description: "Breathable fabric with moisture-wicking technology.",
    isFeatured: true
  },
  {
    id: 5,
    name: "Swift Trail Blazers",
    category: Category.SHOES,
    price: 110.00,
    image: "https://picsum.photos/seed/shoes2/600/600",
    description: "Rugged traction for any terrain.",
    isFeatured: false
  },
  {
    id: 6,
    name: "Grand Slam Carbon Fiber",
    category: Category.BATS,
    price: 180.00,
    image: "https://picsum.photos/seed/bat2/600/600",
    description: "Lightweight carbon fiber for explosive swing speed.",
    isFeatured: false
  },
  {
    id: 7,
    name: "Classic Leather Baseball",
    category: Category.BALLS,
    price: 12.99,
    image: "https://picsum.photos/seed/ball2/600/600",
    description: "Genuine leather cover with cork core.",
    isFeatured: false
  },
  {
    id: 8,
    name: "Strike Training Jersey",
    category: Category.JERSEYS,
    price: 55.00,
    image: "https://picsum.photos/seed/jersey2/600/600",
    description: "Ideal for high-intensity training sessions.",
    isFeatured: false
  },
  {
    id: 9,
    name: "Titanium Catcher's Mask",
    category: Category.EQUIPMENT,
    price: 145.00,
    image: "https://picsum.photos/seed/mask1/600/600",
    description: "Ultra-lightweight protection for elite catchers.",
    isFeatured: true
  }
];
