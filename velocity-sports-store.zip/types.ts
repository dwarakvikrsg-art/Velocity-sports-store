
export enum Category {
  ALL = 'All',
  SHOES = 'Shoes',
  BATS = 'Bats',
  BALLS = 'Balls',
  JERSEYS = 'Jerseys',
  EQUIPMENT = 'Equipment'
}

export interface Product {
  id: number;
  name: string;
  category: Category;
  price: number;
  image: string;
  description: string;
  isFeatured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}
