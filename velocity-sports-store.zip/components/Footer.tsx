
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center">
              <span className="text-2xl font-black text-orange-500 italic">VELOCITY</span>
              <span className="text-2xl font-light text-white ml-1">SPORTS</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Equipping champions since 2010. We provide premium sports gear for professional athletes and weekend warriors alike. Push your limits with Velocity.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-xl"><i className="fa-brands fa-facebook"></i></a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-xl"><i className="fa-brands fa-instagram"></i></a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-xl"><i className="fa-brands fa-twitter"></i></a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-xl"><i className="fa-brands fa-youtube"></i></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shop All Products</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Featured Collections</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Gift Cards</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Track Order</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-lg font-bold mb-6">Support</h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Size Guide</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Return & Refunds</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-lg font-bold mb-6">Join the Team</h4>
            <p className="text-gray-400 text-sm mb-4">Get the latest gear drops and exclusive offers delivered to your inbox.</p>
            <form className="flex flex-col space-y-2">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="bg-gray-800 border-none rounded-md px-4 py-3 text-sm focus:ring-2 focus:ring-orange-500 outline-none"
              />
              <button className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-md transition-all shadow-lg">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-xs mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Velocity Sports Store. All rights reserved. Built for performance.
          </p>
          <div className="flex space-x-4 opacity-50 grayscale hover:grayscale-0 transition-all">
             <i className="fa-brands fa-cc-visa text-2xl"></i>
             <i className="fa-brands fa-cc-mastercard text-2xl"></i>
             <i className="fa-brands fa-cc-paypal text-2xl"></i>
             <i className="fa-brands fa-cc-apple-pay text-2xl"></i>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
