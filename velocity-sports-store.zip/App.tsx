
import React, { useState, useCallback, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Products from './pages/Products';
import About from './pages/About';
import Contact from './pages/Contact';
import { Product, CartItem } from './types';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [notification, setNotification] = useState<string | null>(null);

  const handleNavigate = useCallback((page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleAddToCart = useCallback((product: Product) => {
    setCart(prevCart => {
      const existing = prevCart.find(item => item.id === product.id);
      if (existing) {
        return prevCart.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });

    setNotification(`${product.name} added to cart!`);
    setTimeout(() => setNotification(null), 3000);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
      case 'products':
        return <Products onAddToCart={handleAddToCart} />;
      case 'about':
        return <About />;
      case 'contact':
        return <Contact />;
      default:
        return <Home onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
    }
  };

  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <Navbar 
        cartCount={totalItems} 
        onNavigate={handleNavigate} 
        currentPage={currentPage} 
      />
      
      <main className="flex-grow">
        {renderPage()}
      </main>

      <Footer />

      {/* Global Toast Notification */}
      {notification && (
        <div className="fixed bottom-8 right-8 z-[100] bg-gray-900 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center space-x-3 animate-in slide-in-from-right duration-300">
          <div className="bg-orange-600 rounded-full p-2">
            <i className="fa-solid fa-cart-plus text-xs"></i>
          </div>
          <span className="font-bold text-sm tracking-wide">{notification}</span>
        </div>
      )}
    </div>
  );
};

export default App;
