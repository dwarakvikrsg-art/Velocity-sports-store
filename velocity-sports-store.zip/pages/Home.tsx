
import React from 'react';
import { PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';

interface HomeProps {
  onAddToCart: (product: Product) => void;
  onNavigate: (page: string) => void;
}

const Home: React.FC<HomeProps> = ({ onAddToCart, onNavigate }) => {
  const featuredProducts = PRODUCTS.filter(p => p.isFeatured).slice(0, 3);

  return (
    <div className="animate-in fade-in duration-700">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://picsum.photos/seed/hero/1920/1080" 
            alt="Hero Background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl text-white space-y-6">
            <h2 className="text-orange-500 font-bold uppercase tracking-[0.2em] text-sm animate-bounce">
              New Arrival Collection
            </h2>
            <h1 className="text-5xl md:text-7xl font-black leading-tight italic">
              UNLEASH YOUR <br /> 
              <span className="text-orange-500">POTENTIAL.</span>
            </h1>
            <p className="text-lg text-gray-200 max-w-lg font-light leading-relaxed">
              Engineered for champions. Explore our latest range of high-performance footwear, apparel, and equipment designed to help you dominate the field.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <button 
                onClick={() => onNavigate('products')}
                className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-full font-bold transition-all shadow-xl hover:scale-105"
              >
                Shop Now
              </button>
              <button 
                onClick={() => onNavigate('about')}
                className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-full font-bold transition-all"
              >
                Our Story
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats/Features Banner */}
      <section className="bg-white py-12 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2">
              <i className="fa-solid fa-truck-fast text-orange-600 text-2xl"></i>
              <h3 className="font-bold text-gray-900">Free Delivery</h3>
              <p className="text-xs text-gray-500">On orders over $99</p>
            </div>
            <div className="space-y-2">
              <i className="fa-solid fa-shield-halved text-orange-600 text-2xl"></i>
              <h3 className="font-bold text-gray-900">Secure Payment</h3>
              <p className="text-xs text-gray-500">100% encrypted</p>
            </div>
            <div className="space-y-2">
              <i className="fa-solid fa-rotate-left text-orange-600 text-2xl"></i>
              <h3 className="font-bold text-gray-900">30 Day Returns</h3>
              <p className="text-xs text-gray-500">Hassle-free exchange</p>
            </div>
            <div className="space-y-2">
              <i className="fa-solid fa-headset text-orange-600 text-2xl"></i>
              <h3 className="font-bold text-gray-900">24/7 Support</h3>
              <p className="text-xs text-gray-500">Dedicated assistance</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 space-y-4 md:space-y-0">
            <div>
              <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-2">HOT PICKS</h2>
              <div className="h-1.5 w-20 bg-orange-600 rounded-full"></div>
              <p className="mt-4 text-gray-500 max-w-md">Our most popular gear, battle-tested by the pros and ready for your next session.</p>
            </div>
            <button 
              onClick={() => onNavigate('products')}
              className="text-orange-600 font-bold hover:underline flex items-center group"
            >
              View All Products <i className="fa-solid fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map(product => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={onAddToCart} 
              />
            ))}
          </div>
        </div>
      </section>

      {/* Promo Section */}
      <section className="py-20 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gray-900 rounded-[2.5rem] overflow-hidden flex flex-col lg:flex-row items-center shadow-2xl">
            <div className="p-12 lg:p-20 lg:w-1/2 space-y-6">
              <span className="text-orange-500 font-bold uppercase tracking-widest text-sm">Member Exclusive</span>
              <h2 className="text-4xl md:text-5xl font-black text-white italic">JOIN THE <br /> VELOCITY CLUB</h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                Unlock 20% off your first purchase, early access to new drops, and members-only events.
              </p>
              <button className="bg-white text-gray-900 hover:bg-orange-500 hover:text-white px-10 py-4 rounded-full font-black transition-all transform hover:-translate-y-1">
                Join Now for Free
              </button>
            </div>
            <div className="lg:w-1/2 h-80 lg:h-[500px] w-full">
              <img 
                src="https://picsum.photos/seed/club/800/800" 
                alt="Velocity Club" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
