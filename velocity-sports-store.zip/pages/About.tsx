
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-500">
      {/* Header */}
      <section className="bg-gray-900 py-24 relative overflow-hidden">
         <div className="absolute inset-0 opacity-20">
            <img src="https://picsum.photos/seed/stadium/1920/600" className="w-full h-full object-cover grayscale" />
         </div>
         <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
            <h1 className="text-5xl md:text-7xl font-black mb-6 italic">WE ARE VELOCITY.</h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto font-light leading-relaxed">
              Founded on the belief that everyone has an athlete inside them, waiting to be unleashed.
            </p>
         </div>
      </section>

      {/* Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-orange-100 rounded-2xl -z-10"></div>
              <img 
                src="https://picsum.photos/seed/founders/800/600" 
                alt="Velocity History" 
                className="rounded-3xl shadow-2xl relative"
              />
              <div className="absolute -bottom-6 -right-6 bg-orange-600 text-white p-8 rounded-2xl shadow-xl hidden md:block">
                <span className="text-4xl font-black block">14+</span>
                <span className="text-sm font-bold uppercase tracking-wider">Years of Excellence</span>
              </div>
            </div>
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="text-4xl font-black text-gray-900 italic">OUR STORY</h2>
                <div className="h-1.5 w-20 bg-orange-600 rounded-full"></div>
              </div>
              <p className="text-gray-600 text-lg leading-relaxed">
                Born in a small garage in 2010, Velocity Sports began with a single mission: to provide athletes with high-performance gear that doesn't compromise on style or durability.
              </p>
              <p className="text-gray-600 text-lg leading-relaxed">
                Today, we serve over 500,000 customers globally, ranging from youth league beginners to professional world champions. Our team of designers and athletes work side-by-side to push the boundaries of materials and ergonomics.
              </p>
              <div className="grid grid-cols-2 gap-8 pt-4">
                <div className="space-y-2">
                  <h4 className="text-orange-600 font-black text-2xl italic">QUALITY</h4>
                  <p className="text-sm text-gray-500">Premium materials sourced sustainably.</p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-orange-600 font-black text-2xl italic">COMMUNITY</h4>
                  <p className="text-sm text-gray-500">Supporting local youth sports programs.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team / Mission */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
           <h2 className="text-3xl font-black mb-12">THE VELOCITY PROMISE</h2>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-shadow border border-gray-100">
                <div className="w-16 h-16 bg-orange-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <i className="fa-solid fa-heart-pulse text-2xl text-orange-600"></i>
                </div>
                <h3 className="text-xl font-bold mb-4">Innovation First</h3>
                <p className="text-gray-500 leading-relaxed">We constantly iterate our designs based on data from top-tier athletes to ensure you have the edge.</p>
              </div>
              <div className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-shadow border border-gray-100">
                <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <i className="fa-solid fa-earth-americas text-2xl text-blue-600"></i>
                </div>
                <h3 className="text-xl font-bold mb-4">Sustainability</h3>
                <p className="text-gray-500 leading-relaxed">Committed to reducing our carbon footprint by using recycled fabrics and eco-friendly packaging.</p>
              </div>
              <div className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-shadow border border-gray-100">
                <div className="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <i className="fa-solid fa-users text-2xl text-green-600"></i>
                </div>
                <h3 className="text-xl font-bold mb-4">Inclusivity</h3>
                <p className="text-gray-500 leading-relaxed">Sport is for everyone. We design for every body, every age, and every ability level.</p>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default About;
